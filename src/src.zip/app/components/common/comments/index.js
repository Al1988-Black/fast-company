import CommentsList from "./commentsList";
import AddCommentsForm from "./addCommentsForm";
export const AddComment = AddCommentsForm;
export default CommentsList;
